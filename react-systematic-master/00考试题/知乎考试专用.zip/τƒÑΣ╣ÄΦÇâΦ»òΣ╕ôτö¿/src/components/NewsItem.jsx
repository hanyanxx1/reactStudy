import React from "react";
import './NewsItem.less';

const NewsItem = function NewsItem() {
    return <div className="news-item-box">
        新闻详情
    </div>;
};

export default NewsItem;