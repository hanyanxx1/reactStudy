import React from "react";
import './HomeHead.less';

const HomeHead = function HomeHead() {
    return <header className="home-head-box">
        首页头部
    </header>;
};
export default HomeHead;