import React from "react";
import './Home.less';

const Home = function Home() {
    return <div className="home-box">
        首页
    </div >;
};
export default Home;